package com.zy.mac.petsshow;

public class Pet {
        private String name;
        private int imageResourceID;
        private Boolean isTart;

        private Pet(String _name, int _id, Boolean _isTart){
            this.name = _name;
            this.imageResourceID = _id;
            this.isTart = _isTart;
        }

        public static final Pet[] types = {
                /*Work here once images are done*/
                new Pet("Birds", R.drawable.birds, true),
                new Pet("Dogs", R.drawable.dogs, false),
                new Pet("Cats", R.drawable.cats, false),
        };

        public String getName(){
            return name;
        }

        public int getImageResourceID(){
            return imageResourceID;
        }

        public Boolean getIsTart(){
            return isTart;
        }

        public String toString(){
            return this.name;
        }

    }
