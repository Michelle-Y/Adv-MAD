package com.zy.mac.petsshow;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class petActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order);

        setContentView(R.layout.order);

        int petnum = (Integer)getIntent().getExtras().get("petid");
        Pet pet = Pet.types[petnum];

        ImageView petImage = (ImageView)findViewById(R.id.petImageView);
        petImage.setImageResource(pet.getImageResourceID());

        TextView petName = (TextView)findViewById(R.id.pet_name);
        petName.setText(pet.getName());

        TextView petTartness = (TextView)findViewById(R.id.tartText);
        if(pet.getIsTart()){
            petTartness.setText("Intelligent and beautiful, companion birds bring many benefits to their owners, such as long lifespan, social interaction, empathy, and lower Stress.");
        }else{
            petTartness.setText("Dogs and cats are always been humans’ best friends. Dogs are loyal companions who completely change the daily routines of the people who open up their lives and homes to them. Cats are great for curling up with in front of a fire or for joining us for a lazy day spent in bed with a good book.");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent intent = new Intent(this, PetDetailsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
