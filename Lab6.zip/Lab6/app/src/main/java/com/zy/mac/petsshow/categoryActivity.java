package com.zy.mac.petsshow;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class categoryActivity extends ListActivity {
    private String pettype;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        pettype = intent.getStringExtra("pettype");
        ListView listApples = getListView();
        ArrayAdapter<Pet> listAdapter;
        switch(pettype){
            case "Types":
                listAdapter = new ArrayAdapter<Pet>(this, android.R.layout.simple_list_item_1, Pet.types);
                break;
            default:
                listAdapter = new ArrayAdapter<Pet>(this, android.R.layout.simple_list_item_1, Pet.types);
        }
        listApples.setAdapter(listAdapter);
    }

    @Override
    public void onListItemClick(ListView listView, View view, int position, long id){
        Intent intent = new Intent(categoryActivity.this, petActivity.class);
        intent.putExtra("petid", (int) id);
        startActivity(intent);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.cart:
                Intent intent = new Intent(this, PetDetailsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
